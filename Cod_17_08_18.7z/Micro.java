public class Micro{

	private int preco;


	public void entDados(int val){

		if(val > 0){
			preco = val;
		}
		else{
			System.out.println("\n Problema - Preco Negativo ");
		}
	}


	public void impDados(){
		System.out.println("\n Preco MicOnd: "+ preco);
	}
	
}