public class TstMicro{


	public static void main(String arg[]){

		Micro mic = new Micro();

		mic.entDados(124);

		mic.impDados();

	}
	
}